// src/components/tournois/TournoiDetailModal.jsx
import { useEffect, useState } from "react";
import { supabase } from "../../utils/supabaseClient";
import TournoiRacketForm from "./TournoiRacketForm";
import TournoiRacketsTable from "./TournoiRacketsTable";
import NewClientInline from "./NewClientInline";
import { useTournoiRackets } from "../../hooks/useTournoiRackets";
import logo from "../../assets/sportminedor-logo.png";

/* ===== Dates helpers ===== */
function parseD(v) {
  if (!v) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return new Date(v + "T00:00:00");
  const d = new Date(v);
  return isNaN(+d) ? null : d;
}
function fmt(d) {
  return d ? d.toLocaleDateString("fr-FR") : "—";
}
function rangeLabel(row) {
  if (!row) return "—";
  // On privilégie start_date / end_date ; on tolère l’ancien champ "date"
  const start = parseD(row.start_date || row.date);
  const end   = parseD(row.end_date || row.start_date || row.date);
  if (!start && !end) return "—";
  if (start && end && +start !== +end) return `Du ${fmt(start)} au ${fmt(end)}`;
  return `Le ${fmt(start || end)}`;
}

export default function TournoiDetailModal({ tournoi, onClose }) {
  if (!tournoi) return null;

  // `tournoi` peut être un objet {tournoi, start_date, ...} OU une string "nom"
  const initialName = typeof tournoi === "string" ? tournoi : tournoi?.tournoi;
  const [fresh, setFresh] = useState(
    typeof tournoi === "object" && tournoi ? tournoi : null
  );

  const tournoiName = fresh?.tournoi || initialName || "Tournoi";
  const [isFull, setIsFull] = useState(false);
  const [cordeurs, setCordeurs] = useState([]);
  const [prefillClientId, setPrefillClientId] = useState(null);
  const [showInfos, setShowInfos] = useState(true);

  // Pastilles (compteurs par statut)
  const { countsByStatut } = useTournoiRackets(tournoiName);
  const nAFaire  = countsByStatut["A FAIRE"]  || 0;
  const nARegler = countsByStatut["A REGLER"] || countsByStatut["A RÉGLER"] || 0;
  const nPaye    = countsByStatut["PAYE"]     || countsByStatut["PAYÉ"]     || 0;

  /* ===== Load (row + cordeurs) ===== */
  useEffect(() => {
    let mounted = true;

    async function loadTournament() {
      // si déjà objet complet passé en props, on peut néanmoins rafraîchir depuis la base
      const name = tournoiName;
      if (!name) return;
      const { data, error } = await supabase
        .from("tournois")
        .select("*")
        .eq("tournoi", name)
        .maybeSingle();
      if (!mounted) return;
      if (!error && data) setFresh(data);
    }

    async function loadCordeurs() {
      const name = tournoiName;
      if (!name) return;
      const { data } = await supabase
        .from("tournoi_cordeurs")
        .select("cordeur")
        .eq("tournoi", name);
      if (!mounted) return;
      setCordeurs((data || []).map((d) => d.cordeur));
    }

    loadTournament();
    loadCordeurs();

    const onUpdated = () => {
      loadTournament();
      loadCordeurs();
    };
    window.addEventListener("tournois:updated", onUpdated);

    return () => {
      mounted = false;
      window.removeEventListener("tournois:updated", onUpdated);
    };
  }, [tournoiName]);

  /* ===== UI bits ===== */
  const Pill = ({ bg, value, label, emoji }) => (
    <div
      className="flex items-center gap-2 rounded-full px-3 py-1 text-white"
      style={{ backgroundColor: bg }}
      title={label}
    >
      <span className="mr-1 align-middle relative top-[1px] text-[14px]" aria-hidden>
        {emoji}
      </span>
      <span className="font-extrabold">{value}</span>
      <span className="text-xs opacity-90">{label}</span>
    </div>
  );

  /* ===== Actions: verrouillage ===== */
  async function unlockTournament() {
    if (!confirm("Déverrouiller ce tournoi ? (les gains figés restent enregistrés)")) return;
    try {
      const { error } = await supabase
        .from("tournois")
        .update({ locked: false, locked_at: null })
        .eq("tournoi", tournoiName);
      if (error) throw error;
      const { data: freshRow } = await supabase
        .from("tournois").select("*")
        .eq("tournoi", tournoiName).maybeSingle();
      if (freshRow) setFresh(freshRow);
      window.dispatchEvent(new Event("tournois:updated"));
    } catch(e) {
      console.error(e);
      alert(e?.message || "Échec du déverrouillage");
    }
  }

  async function finalizeTournament() {
    if (!confirm("Figer tous les gains des raquettes cordées et verrouiller le tournoi ?")) return;

    try {
      // 1) Récupérer les lignes du tournoi
      const { data: rows, error: e1 } = await supabase
        .from("tournoi_raquettes")
        .select("id, cordage_id, statut_id, gain_cents")
        .eq("tournoi", tournoiName);
      if (e1) throw e1;

      const norm = (s)=>(s||"").normalize("NFD").replace(/\p{Diacritic}/gu,"").toUpperCase();
      const toFreeze = (rows || []).filter(r => norm(r.statut_id) !== "A FAIRE" && r.gain_cents == null);

      // 2) Charger la grille des gains (cordages.gain_cents)
      const { data: cords, error: e2 } = await supabase
        .from("cordages").select("cordage, gain_cents");
      if (e2) throw e2;
      const gainMap = new Map(
        (cords || []).map(c => [(c.cordage||"").toString().trim().toUpperCase(), Number.isInteger(c.gain_cents)?c.gain_cents:0])
      );

      // 3) Figer
      for (const r of toFreeze) {
        const key = (r.cordage_id || "").toString().trim().toUpperCase();
        const cents = gainMap.get(key) ?? 0;
        const { error: e3 } = await supabase
          .from("tournoi_raquettes")
          .update({ gain_cents: cents, gain_frozen_at: new Date().toISOString() })
          .eq("id", r.id);
        if (e3) throw e3;
      }

      // 4) Verrouiller
      const { error: e4 } = await supabase
        .from("tournois")
        .update({ locked: true, locked_at: new Date().toISOString() })
        .eq("tournoi", tournoiName);
      if (e4) throw e4;

      alert("Gains figés et tournoi verrouillé ✅");
      const { data: freshRow } = await supabase.from("tournois").select("*").eq("tournoi", tournoiName).maybeSingle();
      if (freshRow) setFresh(freshRow);
      window.dispatchEvent(new Event("tournois:updated"));
    } catch (e) {
      console.error(e);
      alert(e?.message || "Échec du verrouillage");
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50" onClick={onClose}>
      <div
        className={`${isFull
          ? "absolute inset-0 h-full w-full max-w-none"
          : "absolute right-0 top-0 h-full w-full max-w-3xl"
        } bg-white shadow-xl p-4 overflow-y-auto transition-all duration-200`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header sticky */}
<div className="sticky top-0 bg-white pb-2 z-10">
  <div className="flex items-start justify-between gap-3">
    {/* Gauche : titre + dates + cordeurs */}
    <div className="min-w-0">
      <div className="text-xl font-semibold flex items-center gap-2">
        <img src={logo} alt="" className="h-5 w-5 rounded-full select-none" />
        <span className="truncate">{tournoiName}</span>
      </div>
      <div className="text-sm text-gray-600">
        {rangeLabel(fresh)}{cordeurs.length ? ` • ${cordeurs.join(" • ")}` : " • —"}
      </div>
    </div>

    {/* Droite : action bar */}
    <div className="flex items-center gap-2 shrink-0">
      {/* Toggle infos */}
      <button
        className="icon-btn"
        title={showInfos ? "Masquer les infos" : "Afficher les infos"}
        onClick={() => setShowInfos((s) => !s)}
        aria-label="Infos"
      >
        ℹ️
      </button>

      {/* Plein écran / réduire */}
      <button
        className="icon-btn"
        title={isFull ? "Réduire la fenêtre" : "Plein écran"}
        onClick={() => setIsFull((v) => !v)}
        aria-label={isFull ? "Réduire" : "Plein écran"}
      >
        <span aria-hidden>{isFull ? "🗗" : "🗖"}</span>
      </button>

      {/* Fermer */}
      <button
        className="icon-btn"
        title="Fermer"
        aria-label="Fermer"
        onClick={onClose}
      >
        ✖
      </button>
    </div>
  </div>
</div>

        {/* Infos (collapsible) */}
        <div className="mt-3">
          <button
            className="text-[#E10600] underline"
            onClick={() => setShowInfos((s) => !s)}
          >
            {showInfos ? "Masquer les infos" : "Afficher les infos"}
          </button>
          {showInfos && (
            <div className="mt-2 whitespace-pre-wrap border rounded-xl p-3">
              {fresh?.infos || "—"}
            </div>
          )}
        </div>

        {/* Mini-form client */}
        <div className="mt-4">
          <NewClientInline onCreated={(id) => setPrefillClientId(id)} />
        </div>

        {/* Form raquette */}
        <div className="mt-4">
          <div className="text-lg font-semibold mb-2">Ajouter une raquette</div>
          <TournoiRacketForm
            tournoiName={tournoiName}
            allowedCordeurs={cordeurs}
            prefillClientId={prefillClientId}
          />
        </div>

        {/* Suivi */}
        <div className="mt-6">
          <TournoiRacketsTable
            tournoiName={tournoiName}
            locked={!!fresh?.locked}
            onFinalize={finalizeTournament}
            onUnlock={unlockTournament}
          />
        </div>
      </div>
    </div>
  );
}